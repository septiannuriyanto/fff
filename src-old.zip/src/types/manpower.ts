export type Manpower = {
  image?: string;
  nrp:string;
  sid_code:string;
  nama: string;
  position: string;
  email?: string;
  contract_date?:string;
  join_date?:string;
  status?: string;
};
