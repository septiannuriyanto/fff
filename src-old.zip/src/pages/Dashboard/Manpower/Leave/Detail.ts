interface Detail {
  id : string,
    nama: string;
    nrp: string;
    position_name: string;
    date_start: string; // You might want to use Date type if it's a date object
    date_end: string; // Similarly, use Date type if it's a date object
    remark: string;
  }