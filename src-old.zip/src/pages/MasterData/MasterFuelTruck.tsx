import React from 'react'

type Props = {}

const MasterFuelTruck = (props: Props) => {
  return (
    <div>MasterFuelTruck</div>
  )
}

export default MasterFuelTruck