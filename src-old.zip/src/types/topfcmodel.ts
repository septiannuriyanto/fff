export type TOPFCMODEL = {
    logo: string;
    cn: string;
    egi: string;
    class: string;
    lossgainpercent: number;
    lossdollar: number;
  };
  