import { useState, useEffect } from 'react';
import DatePickerOne from '../../../../components/Forms/DatePicker/DatePickerOne';
import { formatDateToString, formatDateToYyMmDd } from '../../../../Utils/DateUtility';
import ReusableSwitcher from '../../../../components/Switchers/SwitcherFour';
import SuggestionText from '../../../Dashboard/Manpower/Leave/SuggestionText';
import { Divider } from 'rsuite';
import { LoaderLogoFlex } from '../../../../common/Loader/LoaderLogo';
import DropZone from '../../../../components/DropZones/DropZone';
import { uploadImage } from '../../../../services/ImageUploader';
import { normalizeToTwoDigit } from '../../../../Utils/NumberUtility';
import toast from 'react-hot-toast';
const StockReporting = () => {
  const [date, setDate] = useState<Date | null>(new Date());
  const [shift, setShift] = useState(true);
  useEffect(() => {}, []);

  const handleDateChange = async (date: Date | null) => {
    setDate(date);
  };

  //FOR HANDLING USER DATA============================================
  const [fuelman, setFuelman] = useState('')
  const [operator, setOperator] = useState('')
  const [unit, setUnit] = useState('')


  //FOR STOCK REPORTING======================================================
  const [sondingAwal, setSondingAwal] = useState<number>(0);
  const [sondingAkhir, setSondingAkhir] = useState<number>(0);
  const handleChangeSondingAwal = (e: any) => {
    setSondingAwal(parseFloat(e.target.value));
    localStorage.setItem('sondingAwal', e.target.value);
  };

  const handleChangeSondingAkhir = (e: any) => {
    setSondingAkhir(parseFloat(e.target.value));
    localStorage.setItem('sondingAkhir', e.target.value);
  };



   //FOR ISSUE REPORTING======================================================

  const [fmAwal, setFmAwal] = useState<number>(0);
  const [fmAkhir, setFmAkhir] = useState<number>(0);
  const [flowmeterBeforeFile, setFlowmeterBeforeFile] = useState<File | null>(
    null,
  );
  const [flowmeterAfterFile, setFlowmeterAfterFile] = useState<File | null>(
    null,
  );

  const handleChangeFmAwal = (e: any) => {
    setFmAwal(parseInt(e.target.value));
    localStorage.setItem('fmAwal', e.target.value);
  };
  const handleChangeFmAkhir = (e: any) => {
    setFmAkhir(parseInt(e.target.value));
    localStorage.setItem('fmAkhir', e.target.value);
  };

// const handleFlowmeterBeforeUpload = async (file: File) => {

//     setFlowmeterBeforeFile(file);

//     try {
//       const { imageUrl, error } = await uploadImage(
//         file,
//         'fm-before',
//         `G${formatDateToYyMmDd(new Date())}${normalizeToTwoDigit(
          
//         )}${shift}`,
//         (progress: number) => {
//           console.log(progress);

//         },
//       );

//       if (error) {
//         alert(error);
//         return;
//       }

//       console.log('Flowmeter Before Uploaded:', imageUrl);
//     } catch (error) {
//       console.error('Error uploading file:', error);
//       alert('Error uploading file, please try again.');
//     } finally {
//       toast.success('File Uploaded');
//     }
//   };

  // const handleFlowmeterAfterUpload = async (file: File) => {
  //   setFlowmeterAfterFile(file);

  //   try {
  //     const { imageUrl, error } = await uploadImage(
  //       file,
  //       'fm-after',
  //       `G${formatDateToYyMmDd(new Date())}${normalizeToTwoDigit(
  //         parseInt(reportNumber),
  //       )}`,
  //       (progress: number) => {
  //         console.log(progress);

  //         setUploadProgressFmAfter(progress); // Update upload progress
  //       },
  //     );

  //     if (error) {
  //       alert(error);
  //       return;
  //     }
  //     if (id) {
  //       window.location.reload();
  //     }

  //     console.log('Flowmeter After Uploaded:', imageUrl);
  //   } catch (error) {
  //     console.error('Error uploading file:', error);
  //     alert('Error uploading file, please try again.');
  //   } finally {
  //     setUploadProgressFmAfter(null); // Remove the progress when complete
  //     toast.success('File Uploaded');
  //   }
  // };




  const handleNameSelected = () => {};

  return (
    <>
      <div className=" rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark mb-6">
        <div className="flex flex-wrap items-center">
          <div className="w-full border-stroke dark:border-strokedark xl:border-l-2">
            <div className="w-full p-4 sm:p-12.5 xl:p-5">
              <h2 className="mb-2 font-bold text-black dark:text-white sm:text-title-sm w-full">
                Laporan Stock
              </h2>

              <div className="date__picker bg-white dark:bg-boxdark flex gap-2 w-full ">
                <DatePickerOne
                  enabled={true}
                  handleChange={handleDateChange}
                  setValue={date ? formatDateToString(new Date(date)) : ''}
                />
                <div className="shift__switcher flex flex-row items-center gap-2 w-1/2 justify-center md:justify-start flex-wrap">
                  <ReusableSwitcher
                    textTrue="Shift 1"
                    textFalse="Shift 2"
                    onChange={() => {
                      setShift(!shift);
                      console.log(shift);
                    }}
                  />
                </div>
              </div>
              <div className="input__data mt-6 grid grid-cols-1 md:grid-cols-3 gap-2">
                <SuggestionText
                  label="Fuelman"
                  tableName="manpower"
                  columnName={'nama'}
                  onNameSelected={handleNameSelected}
                ></SuggestionText>
                <SuggestionText
                  label="Operator"
                  tableName="manpower"
                  columnName={'nama'}
                  onNameSelected={handleNameSelected}
                ></SuggestionText>
                <SuggestionText
                  label="Unit"
                  tableName="storage"
                  columnName={'unit_id'}
                  onNameSelected={handleNameSelected}
                ></SuggestionText>
                <div className="sonding_awal">
                  <label className=" text-gray-700 flex items-center">
                    Sonding Awal (cm)
                    <span className="ml-1 w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                  </label>
                  <input
                    value={sondingAwal}
                    type="number"
                    onChange={handleChangeSondingAwal}
                    className="w-full p-2 rounded border-[1.5px] border-stroke"
                  />
                </div>
                <div className="sonding_akhir">
                  <label className=" text-gray-700 flex items-center">
                    Sonding Akhir (cm)
                    <span className="ml-1 w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                  </label>
                  <input
                    value={sondingAkhir}
                    type="number"
                    onChange={handleChangeSondingAkhir}
                    className="w-full p-2 rounded border-[1.5px] border-stroke"
                  />
                </div>
                
              </div>
              

            </div>
            <Divider/>
            <div className="w-full p-4 sm:p-12.5 xl:p-5">
              <h2 className="mb-2 font-bold text-black dark:text-white sm:text-title-sm w-full">
                Laporan Issuing
              </h2>
              <div className="input__data mt-6 grid grid-cols-1 md:grid-cols-3 gap-2">
              <div className="fm_awal">
                  <label className=" text-gray-700 flex items-center">
                    Flowmeter Awal
                    <span className="ml-1 w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                  </label>
                  {flowmeterAfterFile ? (
                <div className="file-preview2">
                  <h2>Uploaded File:</h2>
                  <div className="upload-image-container relative">
                  
                    <img
                      src={URL.createObjectURL(flowmeterAfterFile)}
                      alt="Flowmeter After"
                      className="upload-image h-32 w-32 object-contain bg-slate-700 mt-1"
                    />
                  </div>
                </div>
              ) : (
                <div>
                  <DropZone
                    id="fm-after"
                    title=""
                    onFileUpload={()=>{}}
                  />
                </div>
              )}
                  <input
                    value={fmAwal}
                    type="number"
                    onChange={handleChangeFmAwal}
                    className="w-full p-2 rounded border-[1.5px] border-stroke"
                  />
                </div>
                <div className="fm_akhir">
                  <label className=" text-gray-700 flex items-center">
                    Flowmeter Akhir
                    <span className="ml-1 w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                  </label>
                  <input
                    value={fmAkhir}
                    type="number"
                    onChange={handleChangeFmAkhir}
                    className="w-full p-2 rounded border-[1.5px] border-stroke"
                  />
                </div>
                <div className="unit_count">
                  <label className=" text-gray-700 flex items-center">
                    Jumlah Unit Terisi
                    <span className="ml-1 w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                  </label>
                  <input
                    value={fmAkhir}
                    type="number"
                    onChange={handleChangeFmAkhir}
                    className="w-full p-2 rounded border-[1.5px] border-stroke"
                  />
                </div>

                <div className="qty_refueling">
                  <label className=" text-gray-700 flex items-center">
                    Qty Refueling
                    <span className="ml-1 w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                  </label>
                  <input
                    value={fmAkhir}
                    type="number"
                    onChange={handleChangeFmAkhir}
                    className="w-full p-2 rounded border-[1.5px] border-stroke"
                  />
                </div>
                
              </div>
              

            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default StockReporting;
