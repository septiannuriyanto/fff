interface BarChartSchema {
    desc: string;
    plan_fc: number,
    actual_fc: number,
  }

