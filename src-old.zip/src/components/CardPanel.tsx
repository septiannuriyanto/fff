import React, { ReactNode } from 'react';

interface CardPanelProps {

}

const CardPanel: React.FC<CardPanelProps> = ({
 
}) => {
  return (
    <div className="rounded-sm border border-stroke bg-white py-6 px-7.5 shadow-default dark:border-strokedark dark:bg-boxdark flex items-center">

  </div>
  );
};

export default CardPanel;
