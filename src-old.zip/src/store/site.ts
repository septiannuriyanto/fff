const sitename = 'http://fff-project.vercel.app'


export { sitename }