interface PortionChartSchema {
    CATEGORY: string;
    TOTAL_FUEL_USAGE: number;
  }
  