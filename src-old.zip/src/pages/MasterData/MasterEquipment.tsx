import React from 'react'

type Props = {}

const MasterEquipment = (props: Props) => {
  return (
    <div>MasterEquipment</div>
  )
}

export default MasterEquipment