import { AgGridReact } from 'ag-grid-react';
import React, { useState, useEffect, useRef } from 'react';
import {
  formatDateForSupabase,
  formatDateToString,
} from '../../../../Utils/DateUtility';
import { getQtyByHeight } from '../../../../functions/Interpolate';
import { supabase } from '../../../../db/SupabaseClient';
const IssueReporting = () => {
  const gridRef = useRef();
  const [rowData, setRowData] = useState<any[]>([]);
  const [date, setDate] = useState<Date | null>(new Date());
  const [selecteddShift, setSelectedShift] = useState<string>('1');
  const fullColumns = [
    { id: 'WhouseId', headerName: 'WH ID', field: 'WhouseId', editable: false },
    { id: 'UnitId', headerName: 'Unit ID', field: 'UnitId', editable: false },
    {
      id: 'WorkingShift',
      headerName: 'Shift',
      field: 'WorkingShift',
      editable: true,
    },
    {
      id: 'HeightCm',
      headerName: 'Sonding Awal Shift (cm)',
      field: 'HeightCm',
      editable: true,
    },
    {
      id: 'QtyLiter',
      headerName: 'Qty Awal Shift (L)',
      field: 'QtyLiter',
      editable: false,
    },
    {
      id: 'SOHSystem',
      headerName: 'SOH System',
      field: 'SOHSystem',
      editable: true,
    },
    {
      id: 'PendingPosting',
      headerName: 'Pending Posting',
      field: 'PendingPosting',
      editable: true,
    },
    {
      id: 'PendingReceive',
      headerName: 'Pending Receive',
      field: 'PendingReceive',
      editable: true,
    },
  ];

  const autoSizeStrategy = {
    type: 'fitCellContents',
  };

  useEffect(() => {}, []);

    useEffect(() => {
      fetchWarehouseWithStockTaking(date!, parseInt(selecteddShift));
    }, [date]); // Adding 'date' as a dependency, so it refetches when the date changes

    const fetchWarehouseWithStockTaking = async (paramDate: Date, paramShift:number) => {
        
        // Call the stored procedure using the Supabase RPC functionality
        const { data, error } = await supabase.rpc(
          'fetch_storage_with_stock_taking',
          { p_date: formatDateToString(paramDate), p_shift : paramShift },
        );
    
        if (error) {
          console.log('Error fetching data: ' + error.message);
          return;
        }
    
    
        // Prepare the data for the grid
        const dataRow = data.map((row: any) => ({
          WhouseId: row.warehouse_id,
          WorkingShift : row.working_shift || null,
          UnitId: row.unit_id,
          HeightCm: row.height_cm || null,
          QtyLiter: row.qty_liter || 0,
          SOHSystem: row.soh_system || null,
          PendingPosting: row.pending_posting || null,
          PendingReceive: row.pending_receive || null,
        }));
    
        setRowData(dataRow); // Set the data in the grid
        updateStockStatus(dataRow);
      };

      const updateStockStatus = (dataRow: any) => {
        // Initialize totals
        let totalQtyLiter = 0;
        let totalSOHSystem = 0;
        let totalPendingPosting = 0;
        let totalPendingReceive = 0;
    
        // Iterate through the array and sum values
        dataRow.forEach((record:any) => {
          if (record.QtyLiter != null) {
            totalQtyLiter += record.QtyLiter;
          }
          if (record.SOHSystem != null) {
            totalSOHSystem += record.SOHSystem;
          }
          if (record.PendingPosting != null) {
            totalPendingPosting += record.PendingPosting || 0;
          }
          if (record.PendingReceive != null) {
            totalPendingReceive += record.PendingReceive || 0;
          }
        });
    
        // Update the states with the calculated totals
        // setSohFisik(Math.round(totalQtyLiter));
        // setSohSystem(Math.round(totalSOHSystem));
        // setPendingPosting(Math.round(totalPendingPosting));
        // setPendingReceive(Math.round(totalPendingReceive));
    
        // Calculate the difference
        const calculatedDiff = Math.round(
          totalQtyLiter +
            totalPendingPosting -
            totalSOHSystem -
            totalPendingReceive,
        );
        // setDiff(calculatedDiff);
      };

  const getColumnSum = (columnId: string) => {
    let sum = 0;

    // Loop through each row
    gridRef.current?.api.forEachNode((rowNode: any) => {
      const value = rowNode.data[columnId]; // Get the value of the specific column
      if (value) {
        sum += parseFloat(value); // Add to sum if the value is a valid number
      }
    });

    return sum;
  };

  const checkisRecorded = async (whouseId: string) => {
    const { data, error } = await supabase
      .from('stock_taking')
      .select('*')
      .eq('warehouse_id', whouseId)
      .eq('created_at', formatDateForSupabase(date!));

    if (error) {
      console.log(error.message);
      return;
    }

    return data.length;
  };

  const setOrUpdateDB = async (WhouseId: string, query: any) => {
    //==========================================================================Database Execution
    let isRecorded = await checkisRecorded(WhouseId);
    if (isRecorded == 0) {
      console.log('Create New');
      query = {
        ...query,
        warehouse_id: WhouseId,
        working_shift: selecteddShift,
        created_at: formatDateToString(date!),
      };

      const { error } = await supabase.from('stock_taking').insert([query]);
      if (error) {
        console.error('Error inserting data:', error);
        return false;
      }
      console.log('Data added:', query);
    } else {
      console.log('Update value');
      const { error } = await supabase
        .from('stock_taking')
        .update([query])
        .eq('warehouse_id', WhouseId)
        .eq('created_at', formatDateForSupabase(date!));
      if (error) {
        console.error('Error updating data:', error);
        return false;
      }
      console.log('Data updated:', query);
    }
    //===========================================================================
  };

  const onCellValueChanged = async (params: any) => {
    const { data, oldValue } = params;
    const {
      WhouseId,
      UnitId,
      HeightCm,
      QtyLiter,
      SOHSystem,
      PendingPosting,
      PendingReceive,
    } = data;
    const columnId = params.column.getId();

    // The previous status before the change
    const prevStatus = oldValue;

    //Create Query to be executed
    const query = {
      created_at: formatDateForSupabase(date!),
      warehouse_id: params.data.whouseId,
      height_cm: params.data.HeightCm,
      qty_liter: params.data.liter,
      soh_system: params.data.SOHSystem,
      pending_posting: params.data.PendingPosting,
      pending_receive: params.data.PendingReceive,
    };

    //Select Column ID
    if (columnId == 'WhouseId') {
      console.log('Change WH ID');
    } else if (columnId == 'UnitId') {
      console.log('Change Unit Id');
    } else if (columnId == 'HeightCm') {
      console.log('Change Height Cm');
      const whouseId = params.data.WhouseId;
      let liter = await getQtyByHeight(HeightCm, whouseId);
      params.node.setDataValue('QtyLiter', liter); // Update QtyLiter

      let literSum = getColumnSum('QtyLiter');

      //=========QUERY MODIFICATION
      const query = {
        created_at: formatDateForSupabase(date!),
        warehouse_id: params.data.whouseId,
        height_cm: params.data.HeightCm,
        qty_liter: liter,
        soh_system: params.data.SOHSystem,
        pending_posting: params.data.PendingPosting,
        pending_receive: params.data.PendingReceive,
      };

      await setOrUpdateDB(params.data.WhouseId, query);

      // setSohFisik(Math.round(literSum));
      params.node.setDataValue('WorkingShift', selecteddShift); // Update Working Shift
    } else if (columnId == 'QtyLiter') {
      console.log('Change Qty Liter');
    } else if (columnId == 'SOHSystem') {
      console.log('Change SOH System');
      let literSum = getColumnSum('SOHSystem');
      // setSohSystem(literSum);
      params.node.setDataValue('WorkingShift', selecteddShift); // Update Working Shift

      //=========QUERY MODIFICATION
      const query = {
        soh_system: params.data.SOHSystem,
      };
      await setOrUpdateDB(params.data.WhouseId, query);
    } else if (columnId == 'PendingPosting') {
      console.log('Change Pending Posting');
      let literSum = getColumnSum('PendingPosting');
      // setPendingPosting(Math.round(literSum));
      params.node.setDataValue('WorkingShift', selecteddShift); // Update Working Shift

      //=========QUERY MODIFICATION
      const query = {
        pending_posting: params.data.PendingPosting,
      };
      await setOrUpdateDB(params.data.WhouseId, query);
    } else if (columnId == 'PendingReceive') {
      console.log('Change Pending Receive');
      let literSum = getColumnSum('PendingReceive');
      // setPendingReceive(literSum);
      params.node.setDataValue('WorkingShift', selecteddShift); // Update Working Shift

      //=========QUERY MODIFICATION
      const query = {
        pending_receive: params.data.PendingReceive,
      };
      await setOrUpdateDB(params.data.WhouseId, query);
    } else {
    }

    // Calculate the difference after all related states are updated
    const updatedFisik = getColumnSum('QtyLiter'); // or sohFisik from state
    const updatedSystem = getColumnSum('SOHSystem');
    const updatedPendingPosting = getColumnSum('PendingPosting');
    const updatedPendingReceive = getColumnSum('PendingReceive');

    const newDifference =
      updatedFisik +
      updatedPendingPosting -
      updatedSystem -
      updatedPendingReceive;
    // setDiff(Math.round(newDifference)); // Update diff
  };

  return (
    <>
      <div className=" rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark mb-6">
        <div className="flex flex-wrap items-center">
          <div className="w-full border-stroke dark:border-strokedark xl:border-l-2">
            <div className="w-full p-4 sm:p-12.5 xl:p-5">
              <h2 className="mb-2 font-bold text-black dark:text-white sm:text-title-sm w-full">
                Laporan Issuing
              </h2>

              <div className="stock-report-content flex w-full">
                <div className="stock-report-content w-full">
                  <div className="ag-theme-quartz-auto-dark w-full">
                    <AgGridReact
                      onCellValueChanged={onCellValueChanged}
                      ref={gridRef}
                      columnDefs={fullColumns}
                      rowData={rowData}
                      autoSizeStrategy={autoSizeStrategy}
                      domLayout="autoHeight" // Automatically adjust height based on the number of rows
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default IssueReporting;
