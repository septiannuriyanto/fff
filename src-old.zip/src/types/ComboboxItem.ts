export type ComboBoxItem = {
    value: string;
    label: string;
  };